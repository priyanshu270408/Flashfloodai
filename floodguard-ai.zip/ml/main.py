from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="FloodGuard AI Engine")

class FloodRequest(BaseModel):
    rainfall_intensity: float
    river_level: float
    soil_moisture: float

@app.get("/")
def health_check():
    return {"status": "operational"}

@app.post("/predict")
def predict_flood(req: FloodRequest):
    # Mock prediction logic for prototype
    prob = (req.rainfall_intensity * 0.4) + (req.soil_moisture * 0.3)
    risk = "CRITICAL" if prob > 80 else "HIGH" if prob > 60 else "MODERATE"
    
    return {
        "flood_probability": min(round(prob, 2), 99.9),
        "risk_level": risk,
        "recommendation": "Evacuate" if risk == "CRITICAL" else "Monitor"
    }
