# FLOODGUARD AI (SIH26192)
A Flash Flood Prediction and Early Warning System for Hilly Regions.

## Repository Structure
- `/web` - Next.js React Frontend
- `/ml` - Python FastAPI & XGBoost Prediction Engine
- `/supabase` - PostgreSQL Database Schema & RLS

## Quick Start
1. Run `npm install` in `/web`
2. Run `pip install -r requirements.txt` in `/ml`
3. Add your `.env` variables.
