import React from 'react';

export default function Home() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>FLOODGUARD AI Workspace</h1>
      <p>Your repository is successfully initialized.</p>
      <p><strong>Next Step:</strong> Paste the complete <code>FloodGuardApp.tsx</code> component (from the earlier chat) into this directory to view the UI.</p>
    </div>
  );
}
