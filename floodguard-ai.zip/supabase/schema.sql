-- Run this in your Supabase SQL Editor
CREATE TABLE locations (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    district TEXT NOT NULL,
    state TEXT NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    elevation DOUBLE PRECISION NOT NULL
);

CREATE TABLE alerts (
    id TEXT PRIMARY KEY,
    location_id TEXT REFERENCES locations(id),
    risk_level TEXT NOT NULL,
    reason TEXT NOT NULL,
    status TEXT DEFAULT 'Draft',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
